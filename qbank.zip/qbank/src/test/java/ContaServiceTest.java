import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContaServiceTest {
    @Test
    public void testCriarContaComSaldoValido() {
        ContaService service = new ContaService();
        Conta conta = service.criarConta("Dudão", "Corrente", 100.0);
        assertNotNull(conta);
        assertEquals("Dudão", conta.getNome());
    }

    @Test
    public void testCriarContaComSaldoNegativo() {
        ContaService service = new ContaService();
        assertThrows(IllegalArgumentException.class, () -> {
            service.criarConta("Teste", "Corrente", -50.0);
        });
    }
}
