import java.util.ArrayList;
import java.util.List;

public class ContaService {
    private List<Conta> contas = new ArrayList<>();

    public Conta criarConta(String nome, String tipo, double saldo) {
        if (saldo < 0) throw new IllegalArgumentException("Saldo inicial não pode ser negativo.");
        Conta conta = new Conta(String.valueOf(contas.size() + 1), nome, tipo, saldo);
        contas.add(conta);
        return conta;
    }

    public List<Conta> listarContas() {
        return contas;
    }
}
